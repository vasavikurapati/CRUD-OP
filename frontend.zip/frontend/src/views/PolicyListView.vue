<script setup>
import { ref, onMounted } from 'vue';
import api from '../services/api';

const policies = ref([]);
const isLoading = ref(true);
const error = ref(null);

const fetchPolicies = async () => {
  try {
    isLoading.value = true;
    const response = await api.getPolicies();
    policies.value = response.data;
    error.value = null;
  } catch (err) {
    console.error('Failed to fetch policies:', err);
    error.value = 'Failed to load policies. Ensure the backend is running.';
  } finally {
    isLoading.value = false;
  }
};

const handleDelete = async (policyId) => {
  const confirmed = window.confirm("Are you sure you want to delete this policy?");
  if (confirmed) {
    try {
      await api.deletePolicy(policyId);
      policies.value = policies.value.filter(p => p.id !== policyId);
    } catch (error) {
      console.error("Failed to delete policy:", error);
      alert("Could not delete the policy.");
    }
  }
};

onMounted(() => {
  fetchPolicies();
});
</script>

<template>
  <div v-if="isLoading" class="loading">Loading policies...</div>
  <div v-if="error" class="error">{{ error }}</div>

  <div v-if="!isLoading && !error" class="policy-list">
    <div v-for="policy in policies" :key="policy.id" class="policy-card">
      <h2>{{ policy.name }}</h2>
      <p><strong>Type:</strong> {{ policy.type }}</p>
      <p><strong>Effective Date:</strong> {{ policy.effective_date }}</p>
      <p>{{ policy.description }}</p>
      <div class="card-actions">
        <router-link :to="{ name: 'EditPolicy', params: { id: policy.id } }" class="action-link edit">
          Edit
        </router-link>
        <button @click="handleDelete(policy.id)" class="action-link delete">
          Delete
        </button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.policy-list {
  display: grid;
  gap: 20px;
}
.policy-card {
  border: 1px solid #ddd;
  padding: 15px;
  border-radius: 8px;
  background-color: #f9f9f9;
}
.card-actions {
  margin-top: 15px;
  display: flex;
  gap: 10px;
}
.action-link {
  font-weight: bold;
  text-decoration: none;
  padding: 5px 10px;
  border-radius: 4px;
  border: 1px solid transparent;
}
.edit {
  color: #007bff;
  border-color: #007bff;
}
.delete {
  color: #dc3545;
  border-color: #dc3545;
  background: none;
  cursor: pointer;
  font-family: inherit;
  font-size: inherit;
}
.loading, .error {
  text-align: center;
  padding: 20px;
  font-size: 1.2em;
  color: #555;
}
.error {
  color: red;
}
</style>
