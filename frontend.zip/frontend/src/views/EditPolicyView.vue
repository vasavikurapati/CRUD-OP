<script setup>
import { ref, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import api from '../services/api';
 
const route = useRoute(); // To access route parameters, e.g., the ID
const router = useRouter(); // To navigate programmatically
 
const policy = ref(null); // Will hold the policy data
const errorMessage = ref('');
const isLoading = ref(false);
 
const policyId = route.params.id; // Get the ID from the URL
 
// Fetch the policy data when the component is first loaded
onMounted(async () => {
  try {
    const response = await api.getPolicyById(policyId);
    policy.value = response.data;
  } catch (error) {
    errorMessage.value = 'Failed to load policy data.';
    console.error(error);
  }
});
 
const handleUpdate = async () => {
  isLoading.value = true;
  errorMessage.value = '';
  
  // The backend's PolicyUpdate model doesn't expect 'name' or 'id'
  // So we create an object with only the fields that can be updated.
  const updatePayload = {
    type: policy.value.type,
    scope: policy.value.scope,
    description: policy.value.description,
    effective_date: policy.value.effective_date,
    expiry_date: policy.value.expiry_date,
  };
 
  try {
    await api.updatePolicy(policyId, updatePayload);
    router.push('/'); // Navigate back to the list on success
  } catch (error) {
    errorMessage.value = error.response?.data?.detail || 'An unexpected error occurred.';
    console.error(error);
  } finally {
    isLoading.value = false;
  }
};
</script>
 
<template>
  <div>
    <h2>Edit Policy</h2>
    <div v-if="!policy">Loading...</div>
    
    <form v-else @submit.prevent="handleUpdate" class="policy-form">
      <div class="form-group">
        <label>Policy Name (Cannot be changed)</label>
        <input type="text" :value="policy.name" disabled />
      </div>
 
      <div class="form-group">
        <label for="type">Type</label>
        <select id="type" v-model="policy.type">
          <option>HR</option> <option>IT</option> <option>Finance</option> <option>General</option>
        </select>
      </div>
      <div class="form-group">
        <label for="scope">Scope</label>
        <input id="scope" type="text" v-model="policy.scope" required />
      </div>
      <div class="form-group">
        <label for="description">Description</label>
        <textarea id="description" v-model="policy.description" rows="4"></textarea>
      </div>
      <div class="form-group">
        <label for="effective_date">Effective Date</label>
        <input id="effective_date" type="date" v-model="policy.effective_date" required />
      </div>
      <div class="form-group">
        <label for="expiry_date">Expiry Date</label>
        <input id="expiry_date" type="date" v-model="policy.expiry_date" required />
      </div>
 
      <div v-if="errorMessage" class="error-message">{{ errorMessage }}</div>
      
      <button type="submit" :disabled="isLoading">
        {{ isLoading ? 'Updating...' : 'Update Policy' }}
      </button>
    </form>
  </div>
</template>
 
<style scoped>
/* You can copy the styles from AddPolicyView.vue */
.policy-form { display: flex; flex-direction: column; gap: 15px; }
.form-group { display: flex; flex-direction: column; }
label { margin-bottom: 5px; font-weight: bold; }
input, select, textarea { padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
input:disabled { background-color: #f0f0f0; }
button { padding: 10px 15px; border: none; background-color: #007bff; color: white; border-radius: 4px; cursor: pointer; font-size: 1em; }
button:disabled { background-color: #ccc; }
.error-message { color: red; background-color: #ffebee; border: 1px solid red; padding: 10px; border-radius: 4px; }
</style>
 