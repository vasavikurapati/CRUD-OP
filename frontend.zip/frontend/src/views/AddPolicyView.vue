<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import api from '../services/api';
 
const router = useRouter(); // Get the router instance
 
// Create a reactive object to hold form data, bound using v-model
const newPolicy = ref({
  name: '',
  type: 'HR', // Default value
  scope: '',
  description: '',
  effective_date: '',
  expiry_date: '',
});
 
const errorMessage = ref('');
const isLoading = ref(false);
 
const handleSubmit = async () => {
  isLoading.value = true;
  errorMessage.value = '';
  try {
    // Call the API service to create the policy
    await api.createPolicy(newPolicy.value);
    // On success, navigate back to the home page
    router.push('/');
  } catch (error) {
    // If the API returns an error (e.g., validation failed), display it
    errorMessage.value = error.response?.data?.detail || 'An unexpected error occurred.';
    console.error(error);
  } finally {
    isLoading.value = false;
  }
};
</script>
 
<template>
  <div>
    <h2>Add New Policy</h2>
    <form @submit.prevent="handleSubmit" class="policy-form">
      <div class="form-group">
        <label for="name">Policy Name</label>
        <input id="name" type="text" v-model="newPolicy.name" required />
      </div>
      <div class="form-group">
        <label for="type">Type</label>
        <select id="type" v-model="newPolicy.type">
          <option>HR</option>
          <option>IT</option>
          <option>Finance</option>
          <option>General</option>
        </select>
      </div>
      <div class="form-group">
        <label for="scope">Scope</label>
        <input id="scope" type="text" v-model="newPolicy.scope" required />
      </div>
      <div class="form-group">
        <label for="description">Description</label>
        <textarea id="description" v-model="newPolicy.description" rows="4"></textarea>
      </div>
      <div class="form-group">
        <label for="effective_date">Effective Date</label>
        <input id="effective_date" type="date" v-model="newPolicy.effective_date" required />
      </div>
      <div class="form-group">
        <label for="expiry_date">Expiry Date</label>
        <input id="expiry_date" type="date" v-model="newPolicy.expiry_date" required />
      </div>
 
      <div v-if="errorMessage" class="error-message">{{ errorMessage }}</div>
      
      <button type="submit" :disabled="isLoading">
        {{ isLoading ? 'Saving...' : 'Save Policy' }}
      </button>
    </form>
  </div>
</template>
 
<style scoped>
.policy-form {
  display: flex;
  flex-direction: column;
  gap: 15px;
}
.form-group {
  display: flex;
  flex-direction: column;
}
label {
  margin-bottom: 5px;
  font-weight: bold;
}
input, select, textarea {
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}
button {
  padding: 10px 15px;
  border: none;
  background-color: #007bff;
  color: white;
  border-radius: 4px;
  cursor: pointer;
  font-size: 1em;
}
button:disabled {
  background-color: #ccc;
}
.error-message {
  color: red;
  background-color: #ffebee;
  border: 1px solid red;
  padding: 10px;
  border-radius: 4px;
}
</style>
 