import axios from 'axios';
 
const apiClient = axios.create({
  baseURL: 'http://127.0.0.1:8000/api',
  headers: {
    'Content-Type': 'application/json',
  },
});
 
// ... (keep existing code)

// ... (keep existing code)
 

export default {
  getPolicies() {
    return apiClient.get('/policies/');
  },
  
  createPolicy(policyData) {
    console.log(policyData)
    return apiClient.post('/policies/', policyData);
  },
 

  deletePolicy(id) {
    return apiClient.delete(`/policies/${id}`);
  },
  getPolicyById(id) {
    return apiClient.get(`/policies/${id}`);
  },
 
  updatePolicy(id, policyData) {
    return apiClient.put(`/policies/${id}`, policyData);
  },
};
 
 