import { createRouter, createWebHistory } from 'vue-router';
import PolicyListView from '../views/PolicyListView.vue';
import AddPolicyView from '../views/AddPolicyView.vue';
import EditPolicyView from '../views/EditPolicyView.vue'; // Import the new view
 
const routes = [
  {
    path: '/',
    name: 'PolicyList',
    component: PolicyListView,
  },
  {
    path: '/add',
    name: 'AddPolicy',
    component: AddPolicyView,
  },
  
  {
    path: '/edit/:id', // The ':id' part is a dynamic parameter
    name: 'EditPolicy',
    component: EditPolicyView,
  },
];
 
const router = createRouter({
  history: createWebHistory(),
  routes,
});
 
export default router;
 