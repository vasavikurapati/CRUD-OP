import { createApp } from 'vue'
import App from './App.vue'
import router from './router' // use the router
import './style.css' // global styles

// Create Vue application instance
const app = createApp(App)

app.use(router) // register router

// Global error handler for debugging
app.config.errorHandler = (err, instance, info) => {
  console.error('Global error:', err)
  console.error('Component instance:', instance)
  console.error('Error info:', info)
}

// Global properties (if needed)
app.config.globalProperties.$apiUrl = 'http://localhost:8000/api'

// Mount the application to the DOM element with id="app"
app.mount('#app')

// Optional: Add some debugging info in development
if (import.meta.env.DEV) {
  console.log('Policy Management System started in development mode')
  console.log('API Base URL:', 'http://localhost:8000/api')
}
app.mount('#app')
 
// Optional: Add some debugging info in development
if (import.meta.env.DEV) {
  console.log('Policy Management System started in development mode')
  console.log('API Base URL:', 'http://localhost:8000/api')
}
 
 