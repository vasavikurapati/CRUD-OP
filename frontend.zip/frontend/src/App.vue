<template>
  <div id="app">
    <!-- Header -->
    <header class="header">
      <h1>Policy Management System</h1>
      <nav class="nav">
        <router-link to="/" class="nav-btn" active-class="active" exact>Policy List</router-link>
        <router-link to="/add" class="nav-btn" active-class="active">Add Policy</router-link>
      </nav>
    </header>
 
    <!-- Main Content -->
    <main class="main-content">
      <router-view />
    </main>
  </div>
</template>
 
<script>
const API_BASE_URL = 'http://localhost:8000/api';
 
export default {
  name: 'App',
  data() {
    return {
      currentView: 'list', // 'list', 'add', 'edit'
      policies: [],
      loading: false,
      error: null,
      formLoading: false,
      formData: {
        name: '',
        description: '',
        type: 'HR',            // Default value
        scope: '',
        effective_date: '',    // Expecting YYYY-MM-DD format
        expiry_date: ''
      },
      editingPolicyId: null
    }
  },
  async mounted() {
    await this.loadPolicies();
  },
  methods: {
    async loadPolicies() {
      this.loading = true;
      this.error = null;
 
      try {
        const response = await fetch(`${API_BASE_URL}/policies`);
 
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
 
        const data = await response.json();
        this.policies = data;
      } catch (err) {
        console.error('Error loading policies:', err);
        this.error = 'Failed to load policies. Ensure the backend is running.';
      } finally {
        this.loading = false;
      }
    },
 
    async savePolicy() {
      this.formLoading = true;
 
      try {
        const method = this.currentView === 'add' ? 'POST' : 'PUT';
        const url = this.currentView === 'add'
          ? `${API_BASE_URL}/policies`
          : `${API_BASE_URL}/policies/${this.editingPolicyId}`;
 
        const response = await fetch(url, {
          method,
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(this.formData)
        });
 
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
 
        await this.loadPolicies();
        this.cancelForm();
        this.currentView = 'list';
      } catch (err) {
        console.error('Error saving policy:', err);
        this.error = 'Failed to save policy. Please try again.';
      } finally {
        this.formLoading = false;
      }
    },
 
    async deletePolicy(policyId) {
      if (!confirm('Are you sure you want to delete this policy?')) {
        return;
      }
 
      try {
        const response = await fetch(`${API_BASE_URL}/policies/${policyId}`, {
          method: 'DELETE'
        });
 
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
 
        await this.loadPolicies();
      } catch (err) {
        console.error('Error deleting policy:', err);
        this.error = 'Failed to delete policy. Please try again.';
      }
    },
 
    editPolicy(policy) {
      this.currentView = 'edit';
      this.editingPolicyId = policy.id;
      this.formData = {
        name: policy.name,
        description: policy.description,
        type: policy.type,
        scope: policy.scope,
        effective_date: policy.effective_date,
        expiry_date: policy.expiry_date
      };
    },
 
    cancelForm() {
      this.formData = {
        name: '',
        description: '',
        type: 'HR',
        scope: '',
        effective_date: '',
        expiry_date: ''
      };
      this.editingPolicyId = null;
      this.error = null;
    }
  }
}
</script>
 
<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
 
#app {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  min-height: 100vh;
  background-color: #f5f7fa;
}
 
.header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 1rem 2rem;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  display: flex;
  align-items: center;
  justify-content: space-between;
}
 
.header h1 {
  font-size: 1.2rem;
  font-weight: 400;
}
 
.nav {
  display: flex;
  gap: 1rem;
}
 
.nav-btn {
  background: rgba(255,255,255,0.2);
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 20px;
  text-decoration: none;
}
 
.nav-btn.active {
  background: white;
  color: #667eea;
}
.main-content {
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
}
 
/* Additional styles from the second style block */
.loading {
  text-align: center;
  font-size: 1.2rem;
  color: #667eea;
  padding: 3rem;
}
 
.error {
  background: #fee;
  color: #c33;
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 2rem;
  border-left: 4px solid #c33;
}
 
.policy-list h2 {
  margin-bottom: 2rem;
  color: #333;
  font-weight: 300;
}
 
.no-policies {
  text-align: center;
  color: #666;
  font-size: 1.1rem;
  padding: 3rem;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}
 
.policies-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 2rem;
}
 
.policy-card {
  background: white;
  padding: 1.5rem;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.08);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}
 
.policy-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 30px rgba(0,0,0,0.12);
}
 
.policy-card h3 {
  color: #333;
  margin-bottom: 0.5rem;
  font-size: 1.3rem;
}
 
.policy-card p {
  color: #666;
  line-height: 1.6;
  margin-bottom: 1rem;
}
 
.policy-meta {
  font-size: 0.9rem;
  color: #999;
  margin-bottom: 1rem;
}
 
.policy-actions {
  display: flex;
  gap: 0.5rem;
}
 
.btn-edit, .btn-delete {
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 0.9rem;
  transition: all 0.3s ease;
}
 
.btn-edit {
  background: #667eea;
  color: white;
}
 
.btn-edit:hover {
  background: #5a67d8;
}
 
.btn-delete {
  background: #e53e3e;
  color: white;
}
 
.btn-delete:hover {
  background: #c53030;
}
 
.policy-form {
  max-width: 600px;
  margin: 0 auto;
}
 
.policy-form h2 {
  margin-bottom: 2rem;
  color: #333;
  font-weight: 300;
  text-align: center;
}
 
.form {
  background: white;
  padding: 2rem;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.08);
}
 
.form-group {
  margin-bottom: 1.5rem;
}
 
.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  color: #333;
  font-weight: 500;
}
 
.form-input, .form-textarea {
  width: 100%;
  padding: 0.75rem;
  border: 2px solid #e2e8f0;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.3s ease;
}
 
.form-input:focus, .form-textarea:focus {
  outline: none;
  border-color: #667eea;
}
 
.form-textarea {
  resize: vertical;
  min-height: 100px;
}
 
.form-actions {
  display: flex;
  gap: 1rem;
  justify-content: center;
  margin-top: 2rem;
}
 
.btn-primary, .btn-secondary {
  padding: 0.75rem 2rem;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 1rem;
  transition: all 0.3s ease;
}
 
.btn-primary {
  background: #667eea;
  color: white;
}
 
.btn-primary:hover:not(:disabled) {
  background: #5a67d8;
  transform: translateY(-2px);
}
 
.btn-primary:disabled {
  background: #cbd5e0;
  cursor: not-allowed;
}
 
.btn-secondary {
  background: #e2e8f0;
  color: #4a5568;
}
 
.btn-secondary:hover {
  background: #cbd5e0;
}
 
@media (max-width: 768px) {
  .header {
    padding: 1rem;
  }
 
  .nav {
    flex-direction: column;
  }
 
  .main-content {
    padding: 1rem;
  }
 
  .policies-grid {
    grid-template-columns: 1fr;
  }
 
  .form-actions {
    flex-direction: column;
  }
}
</style>
 
 