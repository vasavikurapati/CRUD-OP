# Expose router so `from app import router` in main.py works
from . import router as router_mod

# router_mod defines `router` (APIRouter) — expose it at package level
router = router_mod.router
