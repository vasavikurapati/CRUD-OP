from pydantic import BaseModel, Field
from datetime import date
from typing import List, Optional
import uuid
 
# This is the base model. It contains fields that are common to all variations of a policy.
class PolicyBase(BaseModel):
    name: str
    type: str
    scope: str
    description: str
    effective_date: date
    expiry_date: date
 
# This model is used when creating a new policy. It inherits from the base model.
class PolicyCreate(PolicyBase):
    pass
 
# This model represents a policy as it is stored in the database, including its ID.
class Policy(PolicyBase):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    document_paths: List[str] = Field(default_factory=list)
 
    class Config:
        orm_mode = True # Helps Pydantic work with ORM-like objects
# ... (keep the other models)
 
# This model is used when updating an existing policy.
# We are excluding 'name' as it should not be updatable.
class PolicyUpdate(BaseModel):
    type: str
    scope: str
    description: str
    effective_date: date
    expiry_date: date
    expiry_date: date
 
 