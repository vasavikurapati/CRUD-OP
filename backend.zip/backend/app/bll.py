from typing import List, Optional
from datetime import date
from .models import Policy, PolicyCreate, PolicyUpdate
from .dal import dal  # Import the DAL instance

class BusinessLogicLayer:
    def get_all_policies(self) -> List[Policy]:
        """Get all policies. Currently no extra logic, just passes through to DAL."""
        return dal.get_all_policies()

    def get_policy_by_id(self, policy_id: str) -> Optional[Policy]:
        """Get a single policy by its ID."""
        return dal.get_policy_by_id(policy_id)

    def create_policy(self, policy_create: PolicyCreate) -> Policy:
        """Business logic for creating a new policy."""
        # 1. Validation Checks
        if policy_create.effective_date < date.today():
            raise ValueError("Effective date cannot be in the past.")

        # Check for duplicate names
        all_policies = self.get_all_policies()
        if any(p.name == policy_create.name for p in all_policies):
            raise ValueError(f"Policy with name '{policy_create.name}' already exists.")

        # 2. Create the full Policy object from the PolicyCreate model
        new_policy = Policy(**policy_create.dict())

        # 3. Pass the new policy to the DAL to be saved
        return dal.add_policy(new_policy)

    def update_policy(self, policy_id: str, policy_update: PolicyUpdate) -> Policy:
        """Business logic for updating a policy."""
        # 1. Fetch the existing policy
        existing_policy = self.get_policy_by_id(policy_id)
        if not existing_policy:
            raise ValueError("Policy not found.")

        # 2. Validation rules
        if existing_policy.effective_date < date.today():
            raise ValueError("Cannot update a policy whose effective date has already passed.")

        if policy_update.expiry_date < policy_update.effective_date:
            raise ValueError("Expiry date cannot be before the effective date.")

        # 3. Create an updated policy object
        updated_policy_data = policy_update.dict()
        updated_policy = existing_policy.copy(update=updated_policy_data)

        # 4. Pass to DAL to save
        return dal.update_policy(policy_id, updated_policy)

    def delete_policy(self, policy_id: str) -> None:
        """Business logic for deleting a policy."""
        # You could add logic here, e.g., "cannot delete an active policy."
        # For now, we'll just pass the request to the DAL.
        return dal.delete_policy(policy_id)

# Instantiate the BLL for use in the API router
bll = BusinessLogicLayer()
