import os

# Optionally load a .env file if python-dotenv is installed
try:
    from dotenv import load_dotenv  # type: ignore
    base_dir = os.path.dirname(os.path.dirname(__file__))
    load_dotenv(os.path.join(base_dir, ".env"))
except Exception:
    # dotenv not available or .env not found — rely on environment variables
    pass


# Required Cosmos DB values (set these in your environment or in backend/.env)
COSMOS_ENDPOINT = os.getenv("COSMOS_ENDPOINT")    # e.g. https://<your-account>.documents.azure.com:443/
COSMOS_KEY = os.getenv("COSMOS_KEY")              # primary key
COSMOS_DATABASE = os.getenv("COSMOS_DATABASE", "policies_db")
COSMOS_CONTAINER = os.getenv("COSMOS_CONTAINER", "policies_container")
COSMOS_PARTITION_KEY = os.getenv("COSMOS_PARTITION_KEY", "/id")

# Mongo/Cosmos MongoAPI connection (connection string you provided)
COSMOS_CONNECTION_STRING = os.getenv("COSMOS_CONNECTION_STRING")  # e.g. mongodb://...
DB_NAME = os.getenv("DB_NAME", COSMOS_DATABASE)
COLLECTION_NAME = os.getenv("COLLECTION_NAME", COSMOS_CONTAINER)

# Helper flags used by DAL to decide which driver to attempt
USE_COSMOS_SQLAPI = bool(COSMOS_ENDPOINT and COSMOS_KEY)
USE_COSMOS_MONGOAPI = bool(COSMOS_CONNECTION_STRING)