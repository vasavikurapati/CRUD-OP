from fastapi import APIRouter, HTTPException, status, Path
from typing import List, Optional
from .models import Policy, PolicyCreate, PolicyUpdate
from .bll import bll
from .dal import dal  # used for health info

router = APIRouter(
    prefix="/api/policies",
    tags=["Policies"] # Groups endpoints in the API docs
)

@router.get("/", response_model=List[Policy])
def read_all_policies():
    """
    Retrieve all policies.
    """
    print(bll.get_all_policies())
    return bll.get_all_policies()

@router.post("/", response_model=Policy, status_code=status.HTTP_201_CREATED)
def create_new_policy(policy: PolicyCreate):
    """
    Create a new policy.
    """
    print(policy)
    try:
        new_policy = bll.create_policy(policy)
        return new_policy
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/{policy_id}", response_model=Policy)
def read_policy_by_id(policy_id: str = Path(..., title="The ID of the policy to get.")):
    """
    Retrieve a single policy by its ID.
    """
    policy = bll.get_policy_by_id(policy_id)
    if not policy:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Policy with ID {policy_id} not found."
        )
    return policy

@router.delete("/{policy_id}", status_code=status.HTTP_200_OK)
def delete_existing_policy(policy_id: str = Path(..., title="The ID of the policy to delete.")):
    """
    Delete an existing policy.
    """
    try:
        bll.delete_policy(policy_id)
        return {"message": "Policy deleted successfully"}
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )

@router.put("/{policy_id}", response_model=Policy)
def update_existing_policy(
    policy_update: PolicyUpdate,
    policy_id: str = Path(..., title="The ID of the policy to update.")
):
    """
    Update an existing policy.
    """
    try:
        return bll.update_policy(policy_id, policy_update)
    except ValueError as e:
        # Distinguish between not found and other validation errors
        if "not found" in str(e).lower():
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
        else:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

@router.get("/health", tags=["Health"])
def health_check():
    """
    Simple health endpoint that reports which storage backend is active.
    """
    return {"storage_backend": getattr(dal, "backend", "unknown")}
