from typing import List, Dict, Optional
from .models import Policy
from . import config
from datetime import date
import logging

# Try Mongo driver (for Cosmos MongoAPI) if connection string provided
USE_MONGO = False
try:
    if config.COSMOS_CONNECTION_STRING:
        from pymongo import MongoClient  # type: ignore
        USE_MONGO = True
except Exception:
    USE_MONGO = False

# Try to import Azure Cosmos SDK (SQL API) as secondary option
USE_COSMOS_SQL = False
try:
    if config.USE_COSMOS_SQLAPI:
        from azure.cosmos import CosmosClient, PartitionKey, exceptions  # type: ignore
        USE_COSMOS_SQL = True
except Exception:
    USE_COSMOS_SQL = False

# --- In-Memory Database (fallback) ---
FAKE_DB: Dict[str, Policy] = {}

def _init_fake_db():
    if FAKE_DB:
        return
    # Initial sample data
    p1 = Policy(
        name="Employee Leave Policy",
        type="HR",
        scope="All Employees",
        description="Policy regarding annual, sick, and other leaves.",
        effective_date=date(2023, 1, 1),
        expiry_date=date(2025, 12, 31),
        document_paths=["policy_documents/some-id-1/leave_policy.pdf"]
    )
    p2 = Policy(
        name="IT Security Policy",
        type="IT",
        scope="All Employees",
        description="Guidelines for protecting company data and systems.",
        effective_date=date(2023, 6, 1),
        expiry_date=date(2024, 6, 1),
        document_paths=["policy_documents/some-id-2/it_security.pdf"]
    )
    FAKE_DB[p1.id] = p1
    FAKE_DB[p2.id] = p2

class DataAccessLayer:
    def __init__(self):
        self.backend = "memory"
        if USE_MONGO:
            # Initialize pymongo client using the provided connection string (Cosmos MongoAPI)
            try:
                self.client = MongoClient(config.COSMOS_CONNECTION_STRING)
                self.db = self.client[config.DB_NAME]
                self.collection = self.db[config.COLLECTION_NAME]
                # Ensure unique index on 'id' to prevent duplicates
                try:
                    self.collection.create_index("id", unique=True)
                except Exception:
                    pass
                self.backend = "mongo"
            except Exception as e:
                logging.exception("Failed to initialize pymongo client, falling back.")
                self.backend = "memory"
                _init_fake_db()
        elif USE_COSMOS_SQL:
            # Initialize Cosmos SQL API client and container
            try:
                self.client = CosmosClient(config.COSMOS_ENDPOINT, credential=config.COSMOS_KEY)
                self.database = self.client.create_database_if_not_exists(id=config.COSMOS_DATABASE)
                try:
                    self.container = self.database.create_container_if_not_exists(
                        id=config.COSMOS_CONTAINER,
                        partition_key=PartitionKey(path=config.COSMOS_PARTITION_KEY),
                        offer_throughput=400
                    )
                except Exception:
                    # fallback partition key
                    self.container = self.database.create_container_if_not_exists(
                        id=config.COSMOS_CONTAINER,
                        partition_key=PartitionKey(path="/id"),
                        offer_throughput=400
                    )
                self.backend = "cosmos_sql"
            except Exception:
                logging.exception("Failed to initialize azure-cosmos client, falling back.")
                self.backend = "memory"
                _init_fake_db()
        else:
            # Use in-memory DB
            _init_fake_db()

    # Helper to convert Policy -> dict (serialize dates to ISO)
    def _policy_to_item(self, policy: Policy) -> dict:
        item = policy.dict()
        # pydantic date -> ISO string
        item['effective_date'] = policy.effective_date.isoformat()
        item['expiry_date'] = policy.expiry_date.isoformat()
        # For Mongo, also set _id to policy.id for uniqueness
        item['_id'] = item.get('id', policy.id)
        return item

    # Helper to convert item (from datastore) -> Policy
    def _item_to_policy(self, item: dict) -> Policy:
        # Remove Mongo's _id if present, keep id
        if '_id' in item:
            # ensure id exists for Pydantic model
            item['id'] = item.get('id', str(item.get('_id')))
            # don't pass _id into Pydantic model
            item = {k: v for k, v in item.items() if k != '_id'}
        # Dates may already be strings or datetimes; Pydantic will coerce ISO strings
        return Policy.parse_obj(item)

    def get_all_policies(self) -> List[Policy]:
        if self.backend == "mongo":
            items = list(self.collection.find({}))
            return [self._item_to_policy(i) for i in items]
        elif self.backend == "cosmos_sql":
            query = "SELECT * FROM c"
            items = list(self.container.query_items(query=query, enable_cross_partition_query=True))
            return [self._item_to_policy(i) for i in items]
        else:
            return list(FAKE_DB.values())

    def get_policy_by_id(self, policy_id: str) -> Optional[Policy]:
        if self.backend == "mongo":
            item = self.collection.find_one({"id": policy_id})
            if not item:
                return None
            return self._item_to_policy(item)
        elif self.backend == "cosmos_sql":
            query = "SELECT * FROM c WHERE c.id=@id"
            items = list(self.container.query_items(query=query, parameters=[{"name":"@id","value":policy_id}], enable_cross_partition_query=True))
            if not items:
                return None
            return self._item_to_policy(items[0])
        else:
            return FAKE_DB.get(policy_id)

    def add_policy(self, policy: Policy) -> Policy:
        if self.backend == "mongo":
            item = self._policy_to_item(policy)
            try:
                self.collection.insert_one(item)
                return self._item_to_policy(item)
            except Exception as e:
                raise ValueError(str(e))
        elif self.backend == "cosmos_sql":
            item = self._policy_to_item(policy)
            try:
                created = self.container.create_item(body=item)
                return self._item_to_policy(created)
            except Exception as e:
                raise ValueError(str(e))
        else:
            if policy.id in FAKE_DB:
                raise ValueError("Policy with this ID already exists.")
            FAKE_DB[policy.id] = policy
            return policy

    def update_policy(self, policy_id: str, updated_policy: Policy) -> Policy:
        if self.backend == "mongo":
            item = self._policy_to_item(updated_policy)
            try:
                result = self.collection.replace_one({"id": policy_id}, item, upsert=True)
                # Return the latest document
                doc = self.collection.find_one({"id": policy_id})
                return self._item_to_policy(doc)
            except Exception as e:
                raise ValueError(str(e))
        elif self.backend == "cosmos_sql":
            item = self._policy_to_item(updated_policy)
            try:
                up = self.container.upsert_item(body=item)
                return self._item_to_policy(up)
            except Exception as e:
                raise ValueError(str(e))
        else:
            if policy_id not in FAKE_DB:
                raise ValueError("Policy not found.")
            FAKE_DB[policy_id] = updated_policy
            return updated_policy

    def delete_policy(self, policy_id: str) -> None:
        if self.backend == "mongo":
            result = self.collection.delete_one({"id": policy_id})
            if result.deleted_count == 0:
                raise ValueError("Policy not found.")
            return None
        elif self.backend == "cosmos_sql":
            try:
                self.container.delete_item(item=policy_id, partition_key=policy_id)
            except Exception as e:
                raise ValueError(str(e))
        else:
            if policy_id not in FAKE_DB:
                raise ValueError("Policy not found.")
            del FAKE_DB[policy_id]

# Instantiate the DAL to be used by other parts of the application
dal = DataAccessLayer()
