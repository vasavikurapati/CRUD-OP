from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app import router # Import the router we just created


app = FastAPI(
    title="Policy Management API",
    description="API for creating, managing, and viewing company policies.",
    version="1.0.0"
)
 
# --- CORS Middleware ---
# This is crucial for allowing your Vue.js frontend to talk to this backend.
# It allows requests from the specified origins (your frontend's URL).
origins = [
    "*"
]
 
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"], # Allow all methods (GET, POST, etc.)
    allow_headers=["*"], # Allow all headers
)
 
 
# Include the router from router.py

@app.get("/", tags=["Root"])
def read_root():
    return {"message": "Welcome to the Policy Management API!"}
#app.include_router(router.router)
app.include_router(router)
